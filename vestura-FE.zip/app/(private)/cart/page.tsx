import Cart from "@/components/cart"

export default function CartPage() {
  return <Cart />
}
