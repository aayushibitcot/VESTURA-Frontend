import Checkout from "@/components/checkout"

export default function CheckoutPage() {
  return <Checkout />
}
