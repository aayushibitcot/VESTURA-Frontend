import Contact from "@/components/contact"

export default function ContactPage() {
  return <Contact />
}
