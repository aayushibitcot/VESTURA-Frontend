import MyOrdersList from "@/components/orders" 

export default function MyOrdersPage() {
  return <MyOrdersList />
}