import OrderSuccess from "@/components/orders/order-success-content"

export default function OrderSuccessPage() {
  return <OrderSuccess />
}
