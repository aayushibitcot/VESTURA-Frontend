import { use } from "react";
import productComponent from "@/components/product"

interface ProductPageProps {
  params: Promise<{ sku: string }>
}

export default function ProductPage({ params }: ProductPageProps) {
  const { sku } = use(params);
  
  return <productComponent sku ={sku} />
}
