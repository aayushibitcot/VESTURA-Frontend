import Shop from "@/components/shop"

export default function ShopPage() {
  return <Shop />
}
