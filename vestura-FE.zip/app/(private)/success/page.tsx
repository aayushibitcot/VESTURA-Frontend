import Success from "@/components/orders/success-content"

export default function SuccessPage() {
  return <Success />
}
