import ChangePassword from "@/components/auth/change-password"

export default function ChangePasswordPage() {
  return <ChangePassword />
}


