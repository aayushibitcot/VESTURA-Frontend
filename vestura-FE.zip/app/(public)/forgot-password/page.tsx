import ForgotPassword from "@/components/auth/forgot-Password"

export default function ForgotPasswordPage() {
  return <ForgotPassword />
}


