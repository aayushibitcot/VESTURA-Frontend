import Home from "@/components/home"

export default function HomePage() {
  return <Home />
}
