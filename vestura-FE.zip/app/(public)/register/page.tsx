import Register from "@/components/auth/register"

export default function RegisterPage() {
  return <Register />
}


