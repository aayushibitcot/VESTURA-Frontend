import ResetPassword from "@/components/auth/reset-password"

export default function ResetPasswordPage() {
  return <ResetPassword />
}


