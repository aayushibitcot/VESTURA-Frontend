import Categories from "./categories-section"

export default function CategoriesSection() {
  return (
    <>
      <Categories /> 
    </>
  )
}
