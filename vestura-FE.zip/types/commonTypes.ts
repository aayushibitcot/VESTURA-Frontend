export type AnyType<T> = T | undefined | null | void | [];

